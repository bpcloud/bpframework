'use strict';

/**
* Copyright (c) 2020 Copyright bp All Rights Reserved.
*/

export class DemoFeignClientBean {
  a: number = 1;
  b: string;
}